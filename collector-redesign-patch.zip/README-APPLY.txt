COLLECTOR REDESIGN PATCH
========================

This patch is built against the live GitHub source at:
  laurenjxviii-art/collector
  main @ cfa417d8eef02050e397eee461cb9c05a97106e6

Replace these files in your existing Collector project:
  app/page.tsx
  app/ItemDetail.tsx
  app/layout.tsx

Add this new file:
  app/collectr.css

Then run your existing DEPLOY-COLLECTOR.cmd or normal Vercel deployment.

Key redesign changes:
- Collectr-style near-black interface with red highlight system.
- Portfolio chart + Holdings Breakdown + Most Valuable + Watchlist preview.
- Dedicated Watchlist page with value change tracking.
- Collections hierarchy now visually follows Type > Line > Collection > Item.
- Collection tiles and product grids redesigned to match the supplied references.
- Transparent PNG/WebP product images render on dark stages without forced white boxes.
- Overview tab on collection pages with a large value chart.
- Quantity + button directly on product cards.
- Jujutsu Kaisen Union Arena progress targets use official Bandai base-set totals:
    Vol.1 / UE03BT: 106 cards (100 numbered + 6 AP)
    Vol.2 / UEX02BT: 90 cards (85 card types + 5 AP)
- Individual item screen rebuilt around the supplied Collectr product-page screenshot:
  large product image, price-history chart, item details, My Collection quantity controls,
  market lookup, watchlist control, and marketplace links.
- Existing useWorkspace/Supabase syncing and market APIs are preserved.
- Existing appearance preferences remain supported.

NOTE
----
The GitHub connector in this chat can read the repository but GitHub rejected write access
with a 403, so this is delivered as a downloadable patch rather than pushed directly.
