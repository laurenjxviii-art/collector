COLLECTOR MARKET REFINEMENT PATCH

Upload this ZIP to the root of laurenjxviii-art/collector using the exact filename:
Collector-source-v7-mobile-polish.zip

Your existing GitHub Actions workflow will expand collector_v6/ over the project and remove the ZIP automatically.
Vercel then runs scripts/apply-market-refinement.mjs before each production build.

This patch:
- Adds a desktop Portfolio "Refresh All Values" button with progress.
- Checks every owned product and only auto-applies >=90% confidence matches.
- Refines provider IDs/UPC/series only when high-confidence and never overwrites conflicting saved identifiers.
- Records low-confidence/conflicting items for manual review instead of guessing.
- Improves eBay sold-listing queries for sports cards, TCGs, comics, figures, and general collectibles.
- Routes sports cards away from JustTCG and into sold-comps/PriceCharting logic.
- Changes green/red product change numbers to current market value vs. price paid (cost basis), not last refresh vs. previous refresh.
- Does not modify the mobile interface.

Important: no system can guarantee 99% accuracy on every collectible. This patch intentionally refuses low-confidence automatic overwrites to maximize accuracy.
