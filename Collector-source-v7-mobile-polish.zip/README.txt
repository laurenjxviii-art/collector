COLLECTOR REDESIGN — EXISTING AUTO-EXPAND WORKFLOW

DO NOT EXTRACT THIS ZIP.
Upload the ZIP itself to the ROOT of the GitHub repo and commit to main.

IMPORTANT: The ZIP filename must remain exactly:
Collector-source-v7-mobile-polish.zip

Your existing GitHub Action watches for that filename. It will:
1. unpack collector_v6/
2. copy the files into the repository
3. remove the ZIP
4. make a bot commit named "Deploy Collector v7 mobile polish"

Because the repository currently contains accidental root-level TSX files from the failed manual upload, the first Vercel build triggered by your upload may fail again. That is expected. Wait for the SECOND commit made by github-actions[bot]. The deployment for that bot commit is the one that should succeed.
